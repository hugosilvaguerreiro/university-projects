﻿namespace DIDA_Client
{
    interface IClient
    {
        void RunScript();
    }
}
