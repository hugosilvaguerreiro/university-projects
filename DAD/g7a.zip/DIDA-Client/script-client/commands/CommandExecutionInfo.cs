﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIDA_API.script_client.commands
{
    class CommandExecutionInfo
    {
        
    }
}
