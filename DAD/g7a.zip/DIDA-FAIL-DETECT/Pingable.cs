﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIDA_FAIL_DETECT
{
    public interface Pingable
    {
        //String GetUrl();
        void IsAlive();
    }
}
