﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIDA_SCRIPT_CLIENT.script_client.commands
{
    class CommandExecutionInfo
    {
        
    }
}
